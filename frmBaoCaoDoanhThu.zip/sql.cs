﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
namespace kieumanhduy
{
    class sql
    {
        public static SqlConnection connect1;
        public static SqlConnection connect()
        {
            try
            {
                connect1 = new SqlConnection("Data Source=192.168.1.11;Initial Catalog=duy5lit;Persist Security Info=True;User ID=sa;Password=duykieu05!;Encrypt=False;Trust Server Certificate=True");
                connect1.Open();
                return connect1;

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return null;
            }
        }
    }
}
