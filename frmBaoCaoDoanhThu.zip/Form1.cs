﻿using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Microsoft.Office.Interop.Excel;
using ExcelApp = Microsoft.Office.Interop.Excel.Application;
namespace kieumanhduy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "BÁO CÁO DOANH THU";
            button2.Enabled = false;
            button3.Enabled = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DateTime a = dateTimePicker1.Value;
            DateTime b = dateTimePicker2.Value;
            SqlConnection c = sql.connect();
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlDataAdapter adt = new SqlDataAdapter();
            string da = a.ToString("yyyy-MM-dd");
            string db = b.ToString("yyyy-MM-dd");
            adt.SelectCommand = new SqlCommand(
                "SELECT CONVERT(date, NgayBan) AS Ngay, " +
                   "SUM(TongTien) AS TongTien " +
                   "FROM tblChiTietHDBan " +
                   "WHERE NgayBan BETWEEN '" + da + "' AND '" + db + "' " +
                   "GROUP BY CONVERT(date, NgayBan) " +
                   "ORDER BY Ngay", c);
            adt.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            dataGridView1.RowTemplate.Height = 90;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Columns["Ngay"].HeaderText = "Ngày bán";
            dataGridView1.Columns["TongTien"].HeaderText = "Tổng tiền";
            button3.Enabled = true;
            button2.Enabled = true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            DateTime a = dateTimePicker1.Value;
            DateTime b = dateTimePicker2.Value;
            SqlConnection c = sql.connect();
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlDataAdapter adt = new SqlDataAdapter();
            string da = a.ToString("yyyy-MM-dd");
            string db = b.ToString("yyyy-MM-dd");
            adt.SelectCommand = new SqlCommand(
                "SELECT CONVERT(date, NgayBan) AS Ngay, " +
                   "SUM(TongTien) AS TongTien " +
                   "FROM tblChiTietHDBan " +
                   "WHERE NgayBan BETWEEN '" + da + "' AND '" + db + "' " +
                   "GROUP BY CONVERT(date, NgayBan) " +
                   "ORDER BY Ngay", c);
            adt.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Columns["Ngay"].HeaderText = "Ngày bán";
            dataGridView1.Columns["TongTien"].HeaderText = "Tổng tiền";
            dataGridView1.RowTemplate.Height = 90;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            ComExcel.application = newComExcel.Application();
            ComExcel.Workbook exWorkBook;
            ComExcel.Worksheet exWorkSheet;
            exWorkBook = exApp.WorkBooks.Add(ComExcel.XLWBATemplate.xlWBATWorkSheet);
            exWorkSheet = exWorkBook.WorkSheet[1];
            ComExcel.Range exrange;
            exrange = exWorkSheet.Cell[1, 1];
            exrange = Range[“a1, b1”].Value = “Bao cao”;
            exApp.Visible = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
